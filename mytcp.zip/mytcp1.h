#pragma once
#include <QAbstractSocket>
#include <QObject>
#include <QtWidgets/QMainWindow>
#include "ui_mytcp1.h"
#include <assert.h>
#include <QTcpServer>
#include <QTcpSocket>
#include <QDebug>
#include <QDataStream>
#include<iostream>

using namespace std;
class mytcp1 : public QMainWindow
{
    Q_OBJECT

public:
    mytcp1(QWidget *parent = Q_NULLPTR);
	
	QTcpServer *myserver;
	QTcpSocket *mysocket;
	public slots:
		void MyConnection();
		void MyReceiveData();	
		void SendInfo();
		void TryConnect();
		void DisConnect();
		void CmdData(QString);

		void slotCheckCmdList();
private:
    Ui::mytcp1Class ui;
	QStringList m_cmdlst;
	bool m_bIsHandling;
};

