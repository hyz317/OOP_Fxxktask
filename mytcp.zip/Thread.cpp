#include "Thread.h"
#include "clause_deal.h"
#include "Command.h"
#include <iostream>
#include <stdio.h>
using namespace std;
Thread::Thread(QObject* parent)
{

}

Thread::~Thread()
{
	terminate();
	wait();
}

void Thread::run()
{
	cout << "running" << endl;
	bool ok = true;
	char chBuf[4096];
	while (ok)
	{
		 
		//ok = gets(chBuf);//gets(hStdinDup, chBuf, 4096, &dwRead, NULL);
		if (cin.getline(chBuf,1000))ok = 1;
		else ok = 0;
		if (strlen(chBuf) != 0)
		{
	//		cout << "trans!" << chBuf << "!" << endl;
			QString str = QString(chBuf);
			emit ReceiveCommand(str);
		//	cout << __FUNCTION__ << __LINE__;
		}
	}
}