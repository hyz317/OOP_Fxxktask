#pragma once
#include"Row.h"
#include"Table.h"
#include "Database.h"
#include "DatabaseMap.h"
#include "Command.h"
#include "clause_deal.h"


int maindeal(char cmd[]);