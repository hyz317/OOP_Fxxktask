/********************************************************************************
** Form generated from reading UI file 'mytcp1.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYTCP1_H
#define UI_MYTCP1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mytcp1Class
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *Port;
    QPushButton *ConButton;
    QTextEdit *SendData;
    QPushButton *SenButton;
    QTextEdit *RecData;
    QMenuBar *menuBar;
    QMenu *menuMytcp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *mytcp1Class)
    {
        if (mytcp1Class->objectName().isEmpty())
            mytcp1Class->setObjectName(QStringLiteral("mytcp1Class"));
        mytcp1Class->resize(600, 400);
        centralWidget = new QWidget(mytcp1Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        Port = new QLineEdit(centralWidget);
        Port->setObjectName(QStringLiteral("Port"));

        gridLayout->addWidget(Port, 0, 1, 1, 1);

        ConButton = new QPushButton(centralWidget);
        ConButton->setObjectName(QStringLiteral("ConButton"));

        gridLayout->addWidget(ConButton, 0, 2, 1, 1);

        SendData = new QTextEdit(centralWidget);
        SendData->setObjectName(QStringLiteral("SendData"));

        gridLayout->addWidget(SendData, 1, 0, 1, 2);

        SenButton = new QPushButton(centralWidget);
        SenButton->setObjectName(QStringLiteral("SenButton"));

        gridLayout->addWidget(SenButton, 1, 2, 1, 1);

        RecData = new QTextEdit(centralWidget);
        RecData->setObjectName(QStringLiteral("RecData"));

        gridLayout->addWidget(RecData, 2, 0, 1, 2);

        mytcp1Class->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(mytcp1Class);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 23));
        menuMytcp = new QMenu(menuBar);
        menuMytcp->setObjectName(QStringLiteral("menuMytcp"));
        mytcp1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(mytcp1Class);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        mytcp1Class->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(mytcp1Class);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        mytcp1Class->setStatusBar(statusBar);

        menuBar->addAction(menuMytcp->menuAction());

        retranslateUi(mytcp1Class);

        QMetaObject::connectSlotsByName(mytcp1Class);
    } // setupUi

    void retranslateUi(QMainWindow *mytcp1Class)
    {
        mytcp1Class->setWindowTitle(QApplication::translate("mytcp1Class", "mytcp1", 0));
        label->setText(QApplication::translate("mytcp1Class", "Port:", 0));
        Port->setText(QApplication::translate("mytcp1Class", "32058", 0));
        ConButton->setText(QApplication::translate("mytcp1Class", "Listen", 0));
        SenButton->setText(QApplication::translate("mytcp1Class", "send", 0));
        menuMytcp->setTitle(QApplication::translate("mytcp1Class", "mytcp", 0));
    } // retranslateUi

};

namespace Ui {
    class mytcp1Class: public Ui_mytcp1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYTCP1_H
