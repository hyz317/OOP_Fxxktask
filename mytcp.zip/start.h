#include <fstream>
#include <sstream>
#include <string.h>
#include "Row.h"
#include "Table.h"
#include "Database.h"
#include "DatabaseMap.h"
#include "Command.h"

bool saving=false;
bool starting=false;

int cutstring(char* info,string* word){
	char *pdeal;//���ڴ��������ָ�� 
	int how_many_word=0;//word�����Ԫ�ظ���
	pdeal = strtok(info," \t");//�ÿո�Ȱ�ָ��ֳ�һ��һ���ġ����ʡ����������źͻ��ж��������ˣ� 
	while(pdeal)
	{
		word[how_many_word++]=pdeal;
		pdeal=strtok(NULL," \t"); //֮ǰ���ַ������ƻ��ˣ����ҵڶ���ʹ�ÿ�ͷ��ָ�����NULL 
	}
	return how_many_word;
}

void start(DatabaseMap& DB){
	starting=true;
	fstream check;
	check.open("1sqltql.txt",ios::in);
	if(check){
		char cinfo[1200];
		while(check.getline(cinfo,1100)){
			string info=cinfo;
			string word[2];
			word[0]=info.substr(0,info.find(' '));
			word[1]=info.substr(info.find(' ')+1);
			if(!DB.exist(word[0])){
				DB.CreateDatabase(word[0]);
			}
			DB.UseDatabase(word[0]);
			string tablename=word[1];
			string tableFileName="1"+word[0]+"+"+tablename+".txt";
			fstream fin(tableFileName,ios::in);
			char Tinfo[1200];
			fin.getline(Tinfo,1100);
			vector<Attribute> attr;
			string key;
			while(fin.getline(Tinfo,1100)){
				if(!strcmp(Tinfo, "+++++")){
					break; 
				} 
				string Tword[100];//��ÿ�������ɵ��� 
				int how_many_word1=cutstring(Tinfo,Tword);
				
				for(int i=0;i<how_many_word1;i++){
					//cout<<"w "<<Tword[i]<<endl;
				}
				
				Attribute Tattr;
				Tattr.name=Tword[0];
				if(Tword[1]=="int(11)"){
					Tattr.type="int";
				}
				else if(Tword[1]=="char(1)"){
					Tattr.type="char";
				}
				else{
					Tattr.type=Tword[1];
				}
				
				if(Tword[2]=="NO"){
					Tattr.Null=false;
				}
				if(Tword[3]=="PRI"){
					Tattr.Key=true;
					key=Tword[0];
				}
				attr.push_back(Tattr);
			}
			DB.current_db->CreateTable(tablename,attr,key);
			//cout<<DB.getname()<<endl;
			//DB.ShowColumns(tablename);
			fin.getline(Tinfo,1100);
			vector<string> attr_list;
			string Aword[100];
			int how_many_attr=cutstring(Tinfo,Aword);
			for(int i=0;i<how_many_attr;i++){
				attr_list.push_back(Aword[i]);
			}
			while(fin.getline(Tinfo,1100)){
				vector<string> value_list;
				string Vword[100];
				int how_many_value=cutstring(Tinfo,Vword);
				for(int i=0;i<how_many_value;i++){
					value_list.push_back(Vword[i]);
				}
				DB.current_db->table_list[tablename].insert(attr_list,value_list);
			}
			fin.close();
			//cout<<"asdlfjlkj"<<endl;
		}
		check.close();
	}
	starting=false;
}
