#include <fstream>
#include <sstream>
#include <string.h>
#include "Row.h"
#include "Table.h"
#include "Database.h"
#include "DatabaseMap.h"
#include "Command.h"
#include "clause_deal.h"
#include "start.h"
#include "mytcp1.h"
#include <QtWidgets/QApplication>


extern bool saving;

extern DatabaseMap DB;       
using namespace std;
int main(int argc, char *argv[])
{
	if(saving){
	start(DB);
	}
	QApplication a(argc, argv);
	mytcp1 w;
	w.show();
	return a.exec();
}


