﻿#include "mytcp1.h"
#include "maindeal.h"
#include "Thread.h"
#include "maindeal.h"
#include<QTimer>
mytcp1::mytcp1(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	m_bIsHandling = false;
	//ui.m_portLineEdit->setText("5550");
	myserver = new QTcpServer();
	connect(ui.ConButton, SIGNAL(clicked()), this, SLOT(TryConnect()));
	Thread* mythread;
	mythread = new Thread(this);
	connect(mythread, SIGNAL(ReceiveCommand(QString)), this, SLOT(CmdData(QString)));
	mythread->start();
	QTimer *timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(slotCheckCmdList()));
	timer->start(100);
}
void mytcp1::CmdData(QString cmd)
{
	m_cmdlst.append(cmd);
}
void mytcp1::slotCheckCmdList()
{
	if (m_cmdlst.size() > 0)
	{
		QString str = m_cmdlst.first();
		QByteArray ba = str.toLatin1();
		char *cmd = ba.data();
		maindeal(cmd);
		m_cmdlst.removeAt(0);
	}
}
void mytcp1::DisConnect()
{
	mysocket = 0;
}

void mytcp1::MyReceiveData()
{
	cout << "rec data" << endl;
	char buffer[1025];
	int ilen = 0;
	QByteArray ba;
	QString str;
	if (mysocket)
	{
		//ilen=mysocket->read(buffer, 1024);
		ba = mysocket->read(1024);
		str = QString::fromUtf8(ba);
	}
	if (str.length()>0)
	{
		int len = ba.length();
		char cmd[100];
		memcpy(cmd, ba, len);
		maindeal(cmd);
		ui.RecData->append(str);
		memcpy(buffer, str.toLatin1().data(), str.length());
//		cout << "buffer is " << buffer << endl;

	}
}

void mytcp1::MyConnection()
{
	cout << "my con" << endl;
	mysocket = myserver->nextPendingConnection();
	connect(mysocket, SIGNAL(readyRead()), this, SLOT(MyReceiveData()));
	connect(mysocket, SIGNAL(disconnected()), this, SLOT(DisConnect()));
}
void mytcp1::TryConnect()
{
	int port = ui.Port->text().toInt();
	cout << "port=" << port << endl;
	if (myserver->isListening())
	{
		myserver->close();
	}
	if (!myserver->listen(QHostAddress::Any, port)) {
		cout << "failed" << endl;
		return;
	}
	else
	{
		cout << "waiting for connect" << endl;
	}
	connect(myserver, SIGNAL(newConnection()), this, SLOT(MyConnection()));
	connect(ui.SenButton, SIGNAL(clicked()), this, SLOT(SendInfo()));
}

void mytcp1::SendInfo()
{
	if (!mysocket)
	{
		cout << "connection break" << endl;
		return;
	}
	QString buffer;
	buffer = ui.SendData->toPlainText();
	char cbuffer[1024];
	QByteArray ba = buffer.toUtf8();
	strcpy(cbuffer, buffer.toStdString().c_str());
	int send = mysocket->write(ba);//cbuffer, strlen(cbuffer));
	if (send == -1)
	{
		cout << "send failed in server" << endl;
	}
	else
	{
		cout << "send ok in server" << endl;
	}
	/*	cout << "SendInfo" << endl;
	char* something = "rrtql hello my friend";

	int suc = mysocket->write(something,strlen(something) );
	if (-1 == suc)cout << "send failed " << endl;
	else cout << "send okay" << endl;*/
}

