#include <QStringList>
#include <QString>
#include<QDebug>

/*#include"Row.h"
#include"Table.h"
#include "Database.h"
#include "DatabaseMap.h"
#include "Command.h"
#include "clause_deal.h"


DatabaseMap DB;*/
#include <iostream>
#include "maindeal.h"
using namespace std;
DatabaseMap DB;
int maindeal(char cmd[])
{
	QString strcmd(cmd);
	strcmd = strcmd.simplified();//ȥ�����з�����ɿո񣩺������Ŀո񣨱�ɿո�
	QStringList strlst = strcmd.split(';');//���ָ� �γ��ַ�������
	int ct = strlst.size();
	for(int i=0;i<ct;i++)
	{
		std::string command;
		char pdeal2[100];
		strcpy(pdeal2, strlst.at(i).toLatin1().data());
		command = pdeal2;
		Command a(command);
		a.operate();
		clause_deal(pdeal2, command);
	}	
	return 0;
}
