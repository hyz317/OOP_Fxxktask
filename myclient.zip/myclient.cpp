#include "myclient.h"

myclient::myclient(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	ui.Portline->setText("32058");
	/** �������ŵ����� */
	mp_clientSocket = new QTcpSocket();
	connect(ui.Con_button, SIGNAL(clicked()), this, SLOT(TryConnect()));
	connect(ui.Sen_button, SIGNAL(clicked()), this, SLOT(SendData()));

	//	this->TryConnect();
}

void myclient::TryConnect()
{
	cout << "TryCon" << endl;

	QString ip = "127.0.0.1";
	ip = ui.Ipline->text();
	//	cout << "ip="<< ip << endl;
	int port = ui.Portline->text().toInt();
	//	int port = 88888;
	//	cout << "please cin port" << endl;
	//	cin >> port;
	/** ���ȹر���ǰ�е����� */
	mp_clientSocket->abort();
	mp_clientSocket->connectToHost(ip, port);
	if (!mp_clientSocket->waitForConnected(3000))
	{
		cout << "failed connect" << endl;
		return;
	}
	cout << "connect ok" << endl;
	connect(mp_clientSocket, SIGNAL(readyRead()), this, SLOT(ClientData()));

}

void myclient::ClientData()
{
	char Msg[1025];
	QString ss;
	int rlen;

	QByteArray qba;// = m_tcpSocket->readAll();
	qba = mp_clientSocket->read(1024);
	ss = QString::fromUtf8(qba);
	rlen = ss.length();

	if (rlen <= 0)cout << "bad not client" << endl;
	else cout << "good received " << Msg << endl;
	if (rlen <= 0)
	{
		/** ����һ���ж� */
		return;
	}
	//QString message = Msg;
	/** ������һ�� */
//	ui.RecText->clear();
	/** Ȼ�������� */
	ui.RecText->append(ss);
}

void myclient::SendData()
{
	if (!mp_clientSocket)
	{
		cout << "connection break!" << endl;
		return;
	}
	QString buffer;
	buffer = ui.SendText->toPlainText();
	QByteArray ba = buffer.toUtf8();
	char cbuffer[1024];
	//strcpy_s(cbuffer, buffer.toStdString().c_str());
	int send = mp_clientSocket->write(ba);//cbuffer, strlen(cbuffer));
	if (send == -1)
	{
		cout << "send failed in client" << endl;
	}
	else
	{
		cout << "send ok in client" << endl;
	}
}