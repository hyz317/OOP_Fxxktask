#include "myclient.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    myclient w;
    w.show();
    return a.exec();
}
