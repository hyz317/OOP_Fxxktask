#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_myclient.h"
#include <QTcpSocket>
#include<iostream>
using namespace std;

class myclient : public QMainWindow
{
    Q_OBJECT

public:
    myclient(QWidget *parent = Q_NULLPTR);
	private slots:
	void ClientData();
private:
    Ui::myclientClass ui;
	QTcpSocket *mp_clientSocket;
	private slots:
	void TryConnect();
	void SendData();
};
