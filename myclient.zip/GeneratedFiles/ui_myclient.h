/********************************************************************************
** Form generated from reading UI file 'myclient.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYCLIENT_H
#define UI_MYCLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_myclientClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLineEdit *Portline;
    QPushButton *Con_button;
    QTextEdit *SendText;
    QPushButton *Sen_button;
    QTextEdit *RecText;
    QLineEdit *Ipline;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *myclientClass)
    {
        if (myclientClass->objectName().isEmpty())
            myclientClass->setObjectName(QStringLiteral("myclientClass"));
        myclientClass->resize(472, 371);
        centralWidget = new QWidget(myclientClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        Portline = new QLineEdit(centralWidget);
        Portline->setObjectName(QStringLiteral("Portline"));

        gridLayout->addWidget(Portline, 0, 0, 1, 1);

        Con_button = new QPushButton(centralWidget);
        Con_button->setObjectName(QStringLiteral("Con_button"));

        gridLayout->addWidget(Con_button, 0, 1, 1, 1);

        SendText = new QTextEdit(centralWidget);
        SendText->setObjectName(QStringLiteral("SendText"));

        gridLayout->addWidget(SendText, 1, 0, 1, 1);

        Sen_button = new QPushButton(centralWidget);
        Sen_button->setObjectName(QStringLiteral("Sen_button"));

        gridLayout->addWidget(Sen_button, 1, 1, 1, 1);

        RecText = new QTextEdit(centralWidget);
        RecText->setObjectName(QStringLiteral("RecText"));

        gridLayout->addWidget(RecText, 3, 0, 1, 1);

        Ipline = new QLineEdit(centralWidget);
        Ipline->setObjectName(QStringLiteral("Ipline"));

        gridLayout->addWidget(Ipline, 3, 1, 1, 1);

        myclientClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(myclientClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 472, 23));
        myclientClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(myclientClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        myclientClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(myclientClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        myclientClass->setStatusBar(statusBar);

        retranslateUi(myclientClass);

        QMetaObject::connectSlotsByName(myclientClass);
    } // setupUi

    void retranslateUi(QMainWindow *myclientClass)
    {
        myclientClass->setWindowTitle(QApplication::translate("myclientClass", "myclient", 0));
        Con_button->setText(QApplication::translate("myclientClass", "connect", 0));
        Sen_button->setText(QApplication::translate("myclientClass", "send", 0));
        Ipline->setText(QApplication::translate("myclientClass", "127.0.0.1", 0));
    } // retranslateUi

};

namespace Ui {
    class myclientClass: public Ui_myclientClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYCLIENT_H
